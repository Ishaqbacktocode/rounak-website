import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk, Geist_Mono } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/utils";
import { site } from "@/lib/site";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-heading",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const defaultTitle = "Rounak Computers | Cloud, Microsoft & Managed IT Solutions in Dubai";
const defaultDescription =
  "For 20+ years Rounak Computers has delivered cloud, Microsoft 365, cybersecurity, managed IT and infrastructure services across the UAE. Microsoft Gold Partner and Dubai AI Seal recipient.";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: defaultTitle, template: `%s | ${site.name}` },
  description: defaultDescription,
  keywords: [
    "cloud solutions Dubai",
    "managed IT services UAE",
    "Microsoft 365 partner",
    "cybersecurity Dubai",
    "IT AMC services",
    "Rounak Computers",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    title: defaultTitle,
    description: "Cloud, Microsoft, cybersecurity and managed IT services trusted by UAE businesses for over 20 years.",
    type: "website",
    siteName: site.name,
    locale: "en_AE",
    url: "/",
    images: [{ url: "/images/og-image.jpg", width: 1200, height: 630, alt: "Rounak Computers: cloud and managed IT in Dubai" }],
  },
  twitter: { card: "summary_large_image", images: ["/images/og-image.jpg"] },
};

// schema.org data so Google can show your business details in local results.
const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: site.name,
  legalName: site.legalName,
  url: site.url,
  logo: `${site.url}/brand/192.png`,
  image: `${site.url}/images/og-image.jpg`,
  email: site.email,
  telephone: site.phones.office.e164,
  address: {
    "@type": "PostalAddress",
    streetAddress: site.address.street,
    addressLocality: site.address.city,
    addressCountry: site.address.country,
  },
  areaServed: "AE",
  sameAs: [site.instagram],
};

export const viewport: Viewport = {
  themeColor: "#1a3fb8",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={cn(
        "h-full bg-background",
        "antialiased",
        inter.variable,
        spaceGrotesk.variable,
        geistMono.variable,
        "font-sans",
      )}
    >
      <body className="min-h-full flex flex-col">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(organizationJsonLd).replace(/</g, "\\u003c"),
          }}
        />
        {children}
      </body>
    </html>
  );
}
