import type { Metadata } from "next";
import { SiteHeader } from "@/components/home/site-header";
import { Contact } from "@/components/home/contact";
import { SiteFooter } from "@/components/home/site-footer";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Talk to Rounak Computers about cloud, Microsoft 365, cybersecurity and managed IT services in Dubai. Call, email or send us a message.",
  alternates: { canonical: "/contact-us" },
};

export default function ContactPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <SiteHeader />
      <main className="flex-1">
        <Contact />
      </main>
      <SiteFooter />
    </div>
  );
}
