import type { MetadataRoute } from "next";
import { site } from "@/lib/site";
import { sourcePages } from "@/lib/source-content";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const top = new Set(["about-us", "products", "it-services", "cloud-services", "security"]);
  const pages = sourcePages
    .filter((slug) => slug !== "sitemap") // old HTML sitemap page; sitemap.xml replaces it
    .map((slug) => ({
      url: `${site.url}/${slug}`,
      lastModified: now,
      changeFrequency: "monthly" as const,
      priority: top.has(slug) ? 0.8 : 0.6,
    }));
  return [
    { url: site.url, lastModified: now, changeFrequency: "weekly", priority: 1 },
    { url: `${site.url}/contact-us`, lastModified: now, changeFrequency: "yearly", priority: 0.8 },
    ...pages,
  ];
}
