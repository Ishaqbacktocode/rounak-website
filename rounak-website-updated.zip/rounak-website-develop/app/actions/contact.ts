"use server";

import { site } from "@/lib/site";

export type ContactState = {
  status: "idle" | "success" | "error";
  message: string;
  errors: Partial<Record<FieldName, string>>;
  values: Partial<Record<FieldName, string>>;
};

type FieldName = "firstName" | "lastName" | "jobTitle" | "company" | "email" | "phone" | "message";

const FIELDS: FieldName[] = ["firstName", "lastName", "jobTitle", "company", "email", "phone", "message"];
const MAX_LENGTH: Record<FieldName, number> = {
  firstName: 60, lastName: 60, jobTitle: 100, company: 120, email: 160, phone: 40, message: 4000,
};

const escapeHtml = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export async function submitContact(_prev: ContactState, formData: FormData): Promise<ContactState> {
  // Honeypot: real visitors never see or fill this field. Pretend success to bots.
  if (String(formData.get("website") ?? "").trim() !== "") {
    return { status: "success", message: "Thank you! We'll be in touch shortly.", errors: {}, values: {} };
  }

  const values: Partial<Record<FieldName, string>> = {};
  for (const f of FIELDS) values[f] = String(formData.get(f) ?? "").trim().slice(0, MAX_LENGTH[f]);

  const errors: ContactState["errors"] = {};
  if (!values.firstName) errors.firstName = "Please enter your first name.";
  if (!values.lastName) errors.lastName = "Please enter your last name.";
  if (!values.email || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email)) {
    errors.email = "Please enter a valid email address.";
  }
  if (!values.phone || values.phone.replace(/\D/g, "").length < 7) {
    errors.phone = "Please enter a valid phone number.";
  }
  if (Object.keys(errors).length) {
    return { status: "error", message: "Please check the highlighted fields.", errors, values };
  }

  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.CONTACT_TO_EMAIL ?? site.email;
  const from = process.env.CONTACT_FROM_EMAIL; // e.g. "Rounak Website <website@rounakcomputers.com>"
  if (!apiKey || !from) {
    console.error("Contact form: RESEND_API_KEY and CONTACT_FROM_EMAIL must be set.");
    return fallbackError(values);
  }

  const fullName = `${values.firstName} ${values.lastName}`;
  const rows: [string, string | undefined][] = [
    ["Name", fullName], ["Job title", values.jobTitle], ["Company", values.company],
    ["Email", values.email], ["Phone", values.phone], ["Message", values.message],
  ];
  const text = rows.filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`).join("\n");
  const html = `<table cellpadding="6" style="font-family:sans-serif;font-size:14px">${rows
    .filter(([, v]) => v)
    .map(([k, v]) => `<tr><td><b>${k}</b></td><td>${escapeHtml(v!).replace(/\n/g, "<br>")}</td></tr>`)
    .join("")}</table>`;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [to],
        reply_to: values.email,
        subject: `New website enquiry from ${fullName}${values.company ? ` (${values.company})` : ""}`,
        text,
        html,
      }),
    });
    if (!res.ok) {
      console.error("Contact form: Resend error", res.status, await res.text());
      return fallbackError(values);
    }
  } catch (err) {
    console.error("Contact form: send failed", err);
    return fallbackError(values);
  }

  return {
    status: "success",
    message: "Thank you! We've received your message and will get back to you within one business day.",
    errors: {},
    values: {},
  };
}

function fallbackError(values: ContactState["values"]): ContactState {
  return {
    status: "error",
    message: `Sorry, we couldn't send your message. Please call us on ${site.phones.office.display} or email ${site.email}.`,
    errors: {},
    values,
  };
}
