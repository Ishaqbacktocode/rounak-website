# Rounak Computers website

Next.js (App Router) + Tailwind CSS v4. Live at https://www.rounakcomputers.com

## Getting started

```bash
npm install
cp .env.example .env.local   # then fill in the values
npm run dev                  # http://localhost:3000
```

## Environment variables

| Variable | Purpose |
| --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Public URL, used for canonical links, sitemap and social previews |
| `RESEND_API_KEY` | API key from [resend.com](https://resend.com) for the contact form |
| `CONTACT_FROM_EMAIL` | Sender, must be on a domain verified in Resend |
| `CONTACT_TO_EMAIL` | Where enquiries are delivered (defaults to `info@rounakcomputers.com`) |

## Project structure

- `app/page.tsx`: homepage, built from `components/home/*`
- `app/contact-us/`: contact page; the form is `components/home/contact-form.tsx`, handled by the server action in `app/actions/contact.ts`
- `app/[...slug]/`: inner pages (about, products, services, cloud, security, blog), rendered from `content/pages.json`
- `lib/site.ts`: phone numbers, email and address in one place. **Edit business details here.**
- `app/sitemap.ts`, `app/robots.ts`, and the schema.org data in `app/layout.tsx`: SEO

## Inner-page content

Inner pages are stored in `content/pages.json`; nothing is fetched from another site. To create or refresh that file from the old live site (one-off, before switching the domain):

```bash
npm run content:snapshot
```

This also downloads page images into `public/images/pages/`. Review the output and commit both.
