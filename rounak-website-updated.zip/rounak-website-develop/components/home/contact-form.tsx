"use client";

import { useActionState } from "react";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { submitContact, type ContactState } from "@/app/actions/contact";

const initialState: ContactState = { status: "idle", message: "", errors: {}, values: {} };

const inputClass =
  "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 aria-[invalid=true]:border-destructive";

export function ContactForm() {
  const [state, formAction, pending] = useActionState(submitContact, initialState);

  if (state.status === "success") {
    return (
      <div role="status" className="flex flex-col items-center justify-center rounded-3xl border border-border bg-card p-9 text-center">
        <CheckCircle2 className="h-12 w-12 text-primary" />
        <h3 className="mt-5 font-heading text-2xl font-bold">Message sent</h3>
        <p className="mt-3 max-w-sm leading-7 text-muted-foreground">{state.message}</p>
      </div>
    );
  }

  const v = state.values;
  const e = state.errors;

  return (
    <form action={formAction} noValidate className="rounded-3xl border border-border bg-card p-7 lg:p-9">
      {/* Honeypot: hidden from people, tempting to bots */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label>
          Leave this field empty
          <input type="text" name="website" tabIndex={-1} autoComplete="off" />
        </label>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="First name" name="firstName" required placeholder="John" autoComplete="given-name" defaultValue={v.firstName} error={e.firstName} />
        <Field label="Last name" name="lastName" required placeholder="Doe" autoComplete="family-name" defaultValue={v.lastName} error={e.lastName} />
        <Field label="Job title" name="jobTitle" placeholder="IT Manager" autoComplete="organization-title" defaultValue={v.jobTitle} />
        <Field label="Company" name="company" placeholder="Company name" autoComplete="organization" defaultValue={v.company} />
        <Field label="Email address" name="email" type="email" required placeholder="you@company.com" autoComplete="email" defaultValue={v.email} error={e.email} className="sm:col-span-2" />
        <Field label="Phone number" name="phone" type="tel" required placeholder="+971 ..." autoComplete="tel" defaultValue={v.phone} error={e.phone} className="sm:col-span-2" />
        <div className="sm:col-span-2">
          <label htmlFor="message" className="mb-2 block text-sm font-medium">How can we help?</label>
          <textarea id="message" name="message" rows={4} maxLength={4000} defaultValue={v.message}
            placeholder="Tell us about your project or requirement..." className={inputClass} />
        </div>
      </div>

      {state.status === "error" && (
        <p role="alert" className="mt-5 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {state.message}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:gap-3 hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {pending ? "Sending..." : "Submit now"}
        {!pending && <ArrowRight className="h-4 w-4" />}
      </button>
      <p className="mt-4 text-center text-xs text-muted-foreground">
        We&apos;ll get back to you within one business day.
      </p>
    </form>
  );
}

function Field({
  label, name, type = "text", required = false, placeholder, autoComplete, defaultValue, error, className = "",
}: {
  label: string; name: string; type?: string; required?: boolean; placeholder?: string;
  autoComplete?: string; defaultValue?: string; error?: string; className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={name} className="mb-2 block text-sm font-medium">
        {label}
        {required && <span className="text-primary"> *</span>}
      </label>
      <input
        id={name} name={name} type={type} required={required} placeholder={placeholder}
        autoComplete={autoComplete} defaultValue={defaultValue}
        aria-invalid={error ? true : undefined} aria-describedby={error ? `${name}-error` : undefined}
        className={inputClass}
      />
      {error && <p id={`${name}-error`} className="mt-1.5 text-xs text-destructive">{error}</p>}
    </div>
  );
}
