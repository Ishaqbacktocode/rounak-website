import { Mail, Phone, MapPin } from "lucide-react";
import { site } from "@/lib/site";
import { ContactForm } from "@/components/home/contact-form";

const contactDetails = [
  { icon: Mail, label: "Email", value: site.email, href: `mailto:${site.email}` },
  { icon: Phone, label: "Sales", value: site.phones.sales.display, href: site.phones.sales.href },
  { icon: Phone, label: "Office", value: site.phones.office.display, href: site.phones.office.href },
  { icon: MapPin, label: "Visit us", value: site.address.full, href: undefined as string | undefined },
];

export function Contact() {
  return (
    <section id="contact" className="mx-auto max-w-7xl px-6 py-24 lg:px-8 lg:py-32">
      <div className="grid gap-14 lg:grid-cols-2 lg:gap-16">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-primary">
            Let us elevate your business
          </p>
          <h2 className="mt-4 font-heading text-3xl font-bold tracking-tight text-balance sm:text-4xl lg:text-5xl">
            Ready to start a conversation?
          </h2>
          <p className="mt-5 text-lg leading-8 text-muted-foreground text-pretty">
            Transform your business into a future-ready digital enterprise with
            our comprehensive cloud, security and managed IT solutions.
          </p>

          <div className="mt-10 space-y-3">
            {contactDetails.map((detail) => {
              const Icon = detail.icon;
              const content = (
                <div className="flex items-start gap-4 rounded-2xl border border-border bg-card p-5">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      {detail.label}
                    </div>
                    <div className="mt-1 font-medium leading-6">
                      {detail.value}
                    </div>
                  </div>
                </div>
              );
              return detail.href ? (
                <a
                  key={detail.label}
                  href={detail.href}
                  className="block transition-colors hover:[&>div]:border-primary/40"
                >
                  {content}
                </a>
              ) : (
                <div key={detail.label}>{content}</div>
              );
            })}
          </div>
        </div>

        <ContactForm />
      </div>
    </section>
  );
}
