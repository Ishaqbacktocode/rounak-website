import Link from "next/link";
import { Mail, Phone, MapPin, Star } from "lucide-react";
import Image from "next/image";
import { site } from "@/lib/site";

const quickLinks = [
  { label: "About Us", href: "/about-us" },
  { label: "Products", href: "/products" },
  { label: "IT Services", href: "/it-services" },
  { label: "Cloud Services", href: "/cloud-services" },
  { label: "Security", href: "/security" },
  { label: "Contact", href: "/contact-us" },
];

const serviceLinks = [
  { label: "Microsoft 365 & Copilot", href: "/products/microsoft-365" },
  { label: "Azure & Cloud Migration", href: "/cloud-services/azure-cloud-services" },
  { label: "Managed IT & AMC", href: "/it-services/managed-it-services" },
  { label: "Cybersecurity", href: "/security" },
  { label: "CCTV & Structured Cabling", href: "/products/cctv-solutions" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.5fr_1fr_1fr_1.2fr]">
          <div>
            <Link href="/" className="flex items-center" aria-label="Rounak Computers home">
                <Image
                  src="/brand/192.png"
                  alt="Rounak Computers"
                  width={192}
                  height={192}
                  className="h-10 w-auto object-contain sm:h-12"
                />
            </Link>
            <p className="mt-5 max-w-sm leading-7 text-muted-foreground">
              A leading cloud solutions provider in the UAE, helping businesses
              transform through cloud integration, infrastructure management and
              IT security.
            </p>
          </div>

          <div>
            <h3 className="font-heading text-sm font-semibold uppercase tracking-wider">
              Quick Links
            </h3>
            <ul className="mt-5 space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-sm font-semibold uppercase tracking-wider">
              Products &amp; Services
            </h3>
            <ul className="mt-5 space-y-3">
              {serviceLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-sm font-semibold uppercase tracking-wider">
              Contact Us
            </h3>
            <ul className="mt-5 space-y-4 text-sm text-muted-foreground">
              <li>
                <a
                  href={`mailto:${site.email}`}
                  className="flex items-start gap-3 transition-colors hover:text-foreground"
                >
                  <Mail className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  {site.email}
                </a>
              </li>
              <li>
                <a
                  href={site.phones.sales.href}
                  className="flex items-start gap-3 transition-colors hover:text-foreground"
                >
                  <Phone className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  {site.phones.sales.display}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                {site.address.full}
              </li>
              <li>
                <a
                  href={site.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 transition-colors hover:text-foreground"
                >
                <Star className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  Follow us on Instagram
                </a>

              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 text-sm text-muted-foreground sm:flex-row">
          <p>
            &copy; {new Date().getFullYear()} Rounak Computers LLC. All rights
            reserved.
          </p>
          <p>Cloud Solutions &middot; AI &middot; Digital Transformation</p>
        </div>
      </div>
    </footer>
  );
}
