/**
 * One-off content snapshot.
 *
 * Downloads every page listed in lib/source-content.ts from the CURRENT live
 * site, extracts the text, saves the images locally and writes everything to
 * content/pages.json. After that the website no longer depends on the old site.
 *
 * Run it BEFORE you point the domain at the new site:
 *
 *     npm run content:snapshot
 *
 * Then commit content/pages.json and public/images/pages/.
 * Review the result: scraped text sometimes needs a manual tidy-up.
 */
import * as cheerio from "cheerio";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const ORIGIN = process.env.SNAPSHOT_ORIGIN ?? "https://rounakcomputers.com";
const root = path.resolve(import.meta.dirname, "..");
const imageDir = path.join(root, "public", "images", "pages");

// Read the slug list straight from the TypeScript source so there is one list.
const src = await readFile(path.join(root, "lib", "source-content.ts"), "utf8");
const listBlock = src.match(/sourcePages\s*=\s*\[([\s\S]*?)\]\s*as const/)?.[1] ?? "";
const slugs = [...listBlock.matchAll(/"([^"]+)"/g)].map((m) => m[1]);
if (!slugs.length) throw new Error("Could not read sourcePages from lib/source-content.ts");

const clean = (v) => v.replace(/\s+/g, " ").trim();
const SKIP_HEADINGS = /newsletter subscription|quick links|product & services|contact us/i;

async function saveImage(imgSrc) {
  try {
    const url = new URL(imgSrc, ORIGIN).toString();
    const res = await fetch(url);
    if (!res.ok) return undefined;
    const type = res.headers.get("content-type") ?? "";
    const ext =
      path.extname(new URL(url).pathname).toLowerCase() ||
      (type.includes("png") ? ".png" : type.includes("webp") ? ".webp" : ".jpg");
    const buf = Buffer.from(await res.arrayBuffer());
    const name = createHash("sha1").update(url).digest("hex").slice(0, 12) + ext;
    await mkdir(imageDir, { recursive: true });
    await writeFile(path.join(imageDir, name), buf);
    return `/images/pages/${name}`;
  } catch {
    return undefined;
  }
}

async function scrape(slug) {
  const res = await fetch(`${ORIGIN}/${slug}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const $ = cheerio.load(await res.text());
  const main = $("main").first();
  if (!main.length) throw new Error("no <main> element found");

  const rawTitle = clean(
    $("meta[property='og:title']").attr("content") || $("h1, h2").first().text() || $("title").text(),
  );
  // The layout adds " | Rounak Computers", so drop any brand suffix from the stored title.
  const title = rawTitle.replace(/\s*[|\-–—]\s*Rounak Computers.*$/i, "").trim() || rawTitle;
  const description = clean($("meta[name='description']").attr("content") || main.find("p").first().text());
  const firstImage = main.find("img").first().attr("src");
  const image = firstImage ? await saveImage(firstImage) : undefined;

  const sections = [];
  for (const heading of main.find("h1, h2, h3").toArray()) {
    const headingTitle = clean($(heading).text());
    if (!headingTitle || SKIP_HEADINGS.test(headingTitle)) continue;
    const parts = [];
    let next = $(heading).next();
    while (next.length && !/^h[1-3]$/i.test(next[0].tagName)) {
      if (next.is("p, ul, ol")) {
        const text = next.is("p")
          ? clean(next.text())
          : next.find("li").toArray().map((li) => clean($(li).text())).filter(Boolean).join("\n");
        if (text) parts.push(text);
      }
      next = next.next();
    }
    if (!parts.length) continue;
    const kind = /faq|frequently asked|question/i.test(headingTitle)
      ? "faq"
      : /testimonial|client|review|success stor/i.test(headingTitle)
        ? "testimonial"
        : sections.length === 0
          ? "overview"
          : "department";
    sections.push({ title: headingTitle, body: parts.join("\n\n"), kind });
  }

  const paragraphs = main.find("p").toArray().map((n) => clean($(n).text())).filter(Boolean);
  const captured = new Set(sections.map((s) => s.body));
  const orphans = paragraphs.filter((p) => !captured.has(p));
  if (orphans.length) {
    sections.push({
      title: sections.length ? "Product description" : title,
      body: orphans.join("\n\n"),
      kind: sections.length ? "department" : "overview",
    });
  }

  return {
    eyebrow: slug.split("/")[0].replaceAll("-", " "),
    title,
    description,
    intro: paragraphs[0] || description,
    image,
    sections: sections.length ? sections : [{ title, body: description }],
  };
}

const pages = {};
const failed = [];
for (const slug of slugs) {
  try {
    pages[slug] = await scrape(slug);
    console.log("ok    ", slug);
  } catch (err) {
    failed.push(slug);
    console.warn("FAILED", slug, "-", err.message);
  }
}

await mkdir(path.join(root, "content"), { recursive: true });
await writeFile(path.join(root, "content", "pages.json"), JSON.stringify(pages, null, 2) + "\n");
console.log(`\nSaved ${Object.keys(pages).length}/${slugs.length} pages to content/pages.json`);
if (failed.length) console.log("Failed pages (re-run or write by hand):", failed.join(", "));
