import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Lets you open the dev server from another device on your network.
  allowedDevOrigins: ["192.168.56.1"],
  images: {
    formats: ["image/avif", "image/webp"],
  },
};

export default nextConfig;
