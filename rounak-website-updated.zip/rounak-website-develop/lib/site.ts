/**
 * Single source of truth for business details.
 * Change them here and every page, the footer, the schema.org data and the
 * contact emails stay in sync.
 */
export const site = {
  name: "Rounak Computers",
  legalName: "Rounak Computers LLC",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.rounakcomputers.com",
  email: "info@rounakcomputers.com",
  phones: {
    office: { display: "+971 4 386 5656", href: "tel:+97143865656", e164: "+97143865656" },
    sales: { display: "+971 55 475 2832", href: "tel:+971554752832", e164: "+971554752832" },
  },
  address: {
    street: "602, 6th Floor, Al Rifaa Plaza, Khalid Bin Al Waleed Road",
    city: "Dubai",
    country: "AE",
    countryName: "UAE",
    full: "602, 6th Floor, Al Rifaa Plaza, Khalid Bin Al Waleed Road, Dubai, UAE",
  },
  instagram: "https://www.instagram.com/rounakcomputers/",
} as const;
