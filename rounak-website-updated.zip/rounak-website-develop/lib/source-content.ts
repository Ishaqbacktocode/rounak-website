import { readFile } from "node:fs/promises";
import path from "node:path";
import type { PageContent } from "@/components/site-page";

/**
 * Inner-page content lives in content/pages.json (created once with
 * `npm run content:snapshot`). Nothing is fetched from another site at build
 * or request time, so the old website can be switched off safely.
 *
 * To change wording, edit content/pages.json (or replace this loader with MDX
 * later). `contact-us` is now a real route in app/contact-us, so it is not listed.
 */
export const sourcePages = [
  "about-us", "about-us/our-team", "about-us/our-partners", "about-us/clients-and-testimonials", "about-us/faq",
  "products", "products/microsoft-copilot", "products/microsoft-dynamics", "products/microsoft-azure-services", "products/microsoft-365", "products/telephony", "products/cctv-solutions", "products/computer-sales-services", "products/professional-cctv-installation-company-in-dubai",
  "it-services", "it-services/structured-cabling", "it-services/it-amc-services-get-it-annual-maintenance-contract", "it-services/managed-it-services", "it-services/spla", "it-services/structured-cabling-company-dubai", "it-services/expert-it-support-services-dubai", "it-services/comprehensive-it-managed-services-dubai", "it-services/advanced-website-joomla-based-application",
  "cloud-services", "cloud-services/alibaba-cloud", "cloud-services/amazon-web-services", "cloud-services/azure-cloud-services", "cloud-services/disaster-recovery-as-service-draas", "cloud-services/migration-services", "cloud-services/best-solutions-to-backup-your-data", "cloud-services/quality-ibm-watson-workspace-in-dubai", "cloud-services/huawei-cloud-services",
  "security", "security/o365-advance-threat-protection", "security/sophos-security-in-dubai", "security/ibm-mass-360", "security/mimecast-dubai", "security/top-security-solutions-for-ransomware-dubai", "security/barracuda-email-security", "security/guaranteed-information-security-in-dubai",
  "blog", "blog/uae-e-invoicing-the-it-readiness-checklist-before-your-asp-deadline", "blog/still-running-windows-10-esu-costs-and-your-options-in-2026", "blog/barracuda-vs-mimecast-for-uae-businesses-choosing-an-email-security-layer", "privacy-policy", "tos", "sitemap",
] as const;

export type SourcePage = Omit<PageContent, "slug"> & { title: string; description: string };

let cache: Promise<Record<string, SourcePage>> | undefined;

function readPages() {
  cache ??= readFile(path.join(process.cwd(), "content", "pages.json"), "utf8")
    .then((raw) => JSON.parse(raw) as Record<string, SourcePage>)
    .catch(() => {
      console.warn("content/pages.json not found. Run `npm run content:snapshot` first.");
      return {};
    });
  return cache;
}

export async function loadSourcePage(slug: string): Promise<SourcePage | undefined> {
  if (!sourcePages.includes(slug as (typeof sourcePages)[number])) return undefined;
  return (await readPages())[slug];
}
